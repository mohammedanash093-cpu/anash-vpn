package com.anash.anashvpn.interfaces;

import com.anash.anashvpn.model.Server;

public interface ChangeServer {
    void newServer(Server server);
}
