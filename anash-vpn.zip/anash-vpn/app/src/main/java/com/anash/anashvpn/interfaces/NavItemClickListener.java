package com.anash.anashvpn.interfaces;

public interface NavItemClickListener {
    void clickedItem(int index);
}
